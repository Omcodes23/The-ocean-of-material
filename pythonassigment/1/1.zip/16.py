# code by : dev patel
# https://www.github.com/dev22419/

# taking a string
x = "i love msu"

print(x)

if "love" in x:
    print("the word love exist in sentence .")
else:
    print("word don't exist .")