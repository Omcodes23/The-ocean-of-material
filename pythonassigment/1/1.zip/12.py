# code by : dev patel
# https://www.github.com/dev22419/

# area of room = l*b*h

# taking input from user for calculations

l = int(input("enter the length of the room : "))

b = int(input("enter the width of the room : "))

h = int(input("enter the height of the room : "))

# calculations

area = l*b*h

# output

print("")

print("the area of the room is \"" , area , "\".")