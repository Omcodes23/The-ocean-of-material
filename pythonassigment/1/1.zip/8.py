# code by : dev patel
# https://www.github.com/dev22419/

# reading the value from user .
name = input("name: ")              # you can also use try block here for error handleing 
place = input("place: ")

# printing the user input
print("")

print("your name is " + name)

print("your place is " + place)
