# code by : dev patel
# https://www.github.com/dev22419/
print("Hello world")