# code by : dev patel
# https://www.github.com/dev22419/

# making an variable 
name = "dev"

# printing the name 
print("my name is " + name)

# re-assiging the value of variable
name = "Dhyey"

# again , printing the name 
print("my name is " + name)