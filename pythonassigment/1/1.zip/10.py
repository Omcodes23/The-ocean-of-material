# code by : dev patel
# https://www.github.com/dev22419/

# taking input from users 
x = int(input("first number : "))
y = int(input("second number : "))

# adding the numbers
sum = x + y

#printing the output
print("total = " , sum)