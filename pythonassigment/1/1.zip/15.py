# code by : dev patel
# https://www.github.com/dev22419/

# assigning variables

S = 1
a = 2
b = 2
c = 2

# calculations 
Area = (S*(S-a)*(S-b)*(S-c)) ** 0.5
Area = str(Area)

# printing output
print("area of tringle is \"" , Area[1:7] , "\".")