print('Ram\'s wife is Sita')
print("Ram is also known as \"Maryaada Purushottam\"")
print(r'Ram\'s wife is Sita')
print(r"Ram is also known as \"Maryaada Purushottam\"")
