kg=input("Enter the weigth in KG : ")
pounds=float(kg)*2.2
print("Equivlent KG in pounds is",pounds)
