l = float(input('Enter the length of a Rectangle: '))
b = float(input('Enter the breadth of a Rectangle: '))
Area = l * b
print("Area of a Rectangle is: %.2f" %Area)
