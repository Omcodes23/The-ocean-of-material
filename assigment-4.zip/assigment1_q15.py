str=input(("Enter a word : "))
if(str==str[::-1]):
    print("The letter is a pliindrome")
else:
    print("The letter is not a palindrome")


str=input("Enter a word : ")
if str==str[::-1]:
    print("The word is a plindrom.")
else:
    print("The word is not a plendrom.")